jQuery(document).ready(function($) {

  $('.count').counterUp({
      delay: 20,
      time: 1500
  });
  
});